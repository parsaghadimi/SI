# Q3 PARRT 1 AND 2
import numpy as np
from sklearn.datasets import load_iris
import random
import matplotlib.pyplot as plt

# Q3 PART 1 SECTION A
# k-means++
class KMeansPlusPlus:
    def __init__(self, n_clusters, max_iterations=100, loss_threshold=1e-4):
        self.n_clusters = n_clusters
        self.max_iterations = max_iterations
        self.loss_threshold = loss_threshold
        self.centroids = None

    def euclidean_distance(self, a, b):
        return np.sqrt(np.sum((a - b) ** 2))

    def normalize_data(self, X):
        # Normalize the data to the range [0, 1]
        min_vals = np.min(X, axis=0)
        max_vals = np.max(X, axis=0)
        normalized_X = (X - min_vals) / (max_vals - min_vals + 1e-8)
        return normalized_X

    def initialize_centroids(self, X):
        n_samples, n_features = X.shape
        self.centroids = np.empty((self.n_clusters, n_features))
        
        # Randomly select the first centroid
        self.centroids[0] = X[np.random.choice(n_samples)]

        for i in range(1, self.n_clusters):
            distances = np.array([min([self.euclidean_distance(x, centroid) for centroid in self.centroids[:i]]) for x in X])
            probabilities = distances / distances.sum()
            
            # Select the next centroid based on the calculated probabilities
            centroid_index = np.random.choice(n_samples, p=probabilities)
            self.centroids[i] = X[centroid_index]

    def fit(self, X):
        X = self.normalize_data(X)
        self.initialize_centroids(X)

        prev_centroids = np.zeros(self.centroids.shape)
        iteration = 0
        losses = []

        while not np.array_equal(prev_centroids, self.centroids) and iteration < self.max_iterations:
            clusters = [[] for _ in range(self.n_clusters)]

            # Assign each sample to the nearest centroid
            for x in X:
                distances = [self.euclidean_distance(x, centroid) for centroid in self.centroids]
                cluster_index = np.argmin(distances)
                clusters[cluster_index].append(x)

            prev_centroids = np.copy(self.centroids)

            # Update the centroids based on the mean of the assigned samples
            for i, cluster in enumerate(clusters):
                self.centroids[i] = np.mean(cluster, axis=0)

            # Calculate the loss
            loss = np.mean([np.mean([self.euclidean_distance(x, centroid) ** 2 for x in cluster]) for centroid, cluster in zip(self.centroids, clusters)])
            losses.append(loss)
            iteration += 1

            if loss <= self.loss_threshold and iteration >= 3:
                break

        return losses, self.centroids, iteration
# Q3 PART 1 SECTION B
# Load the Iris dataset
iris = load_iris()
X = iris.data

k_values = [1, 2, 3, 4, 5]
k_losses = []
k_iterations = []

best_loss = float('inf')
best_k = None
best_centroids = None

for k in k_values:
    kmeans = KMeansPlusPlus(n_clusters=k)
    losses, centroids, iterations = kmeans.fit(X)
    if(k == 3):
        k_3_centroids = centroids
        print(f'k=3 centroids:\n{k_3_centroids}')
    
    k_losses.append(losses)  
    k_iterations.append(iterations)  
    
    # Check if the current k value gives a better loss
    if losses[-1] < best_loss:
        best_loss = losses[-1]
        best_k = k
        best_centroids = centroids

# Print the results
print('kmeans++')
print(f'Best k: {best_k}')
print(f'Best loss: {best_loss}')
print(f'Best centroids:\n{best_centroids}')

# Q3 PART 1 SECTION C AND D
# Plotting
plt.figure(figsize=(8, 6))

for k, losses in zip(k_values, k_losses):
    plt.plot(range(1, len(losses) + 1), losses, label=f'k = {k}')
# D
plt.xlabel('Iterations')
plt.ylabel('Loss')
plt.title('Loss vs Iterations for Different Values of k(kmeans++)')
plt.legend()
plt.tight_layout()
plt.show()

plt.figure(figsize=(8, 6))
plt.plot(k_values, k_iterations)
plt.xlabel('Number of Clusters (k)')
plt.ylabel('Number of Iterations')
plt.title('Number of Iterations vs Number of Clusters (k)(kmeans++)')
plt.tight_layout()
plt.show()

# C
plt.figure(figsize=(8, 6))
plt.plot(k_values, [losses[-1] for losses in k_losses])
plt.xlabel('Number of Clusters (k)')
plt.ylabel('Loss')
plt.title('Loss vs Number of Clusters (k)(kmeans++)')
plt.tight_layout()
plt.show()



import numpy as np
from sklearn.datasets import load_iris
import random
import matplotlib.pyplot as plt

# Q3 PART 2
# K-median
class KMedian:
    def __init__(self, n_clusters, max_iterations=100, loss_threshold=1e-4):
        self.n_clusters = n_clusters
        self.max_iterations = max_iterations
        self.loss_threshold = loss_threshold
        self.medians = None

    def manhattan_distance(self, a, b):
        return np.sum(np.abs(a - b))

    def normalize_data(self, X):
        # Normalize the data to the range [0, 1]
        min_vals = np.min(X, axis=0)
        max_vals = np.max(X, axis=0)
        normalized_X = (X - min_vals) / (max_vals - min_vals + 1e-8)
        return normalized_X

    def initialize_medians(self, X):
        n_samples, n_features = X.shape
        self.medians = np.empty((self.n_clusters, n_features))
        
        # Randomly select the first median
        self.medians[0] = X[np.random.choice(n_samples)]

        for i in range(1, self.n_clusters):
            distances = np.array([min([self.manhattan_distance(x, median) for median in self.medians[:i]]) for x in X])
            probabilities = distances / distances.sum()
            
            # Select the next median based on the calculated probabilities
            median_index = np.random.choice(n_samples, p=probabilities)
            self.medians[i] = X[median_index]

    def fit(self, X):
        X = self.normalize_data(X)
        self.initialize_medians(X)

        prev_medians = np.zeros(self.medians.shape)
        iteration = 0
        losses = []

        while not np.array_equal(prev_medians, self.medians) and iteration < self.max_iterations:
            clusters = [[] for _ in range(self.n_clusters)]

            # Assign each sample to the nearest median
            for x in X:
                distances = [self.manhattan_distance(x, median) for median in self.medians]
                cluster_index = np.argmin(distances)
                clusters[cluster_index].append(x)

            prev_medians = np.copy(self.medians)

            # Update the medians based on the median of the assigned samples
            for i, cluster in enumerate(clusters):
                self.medians[i] = np.median(cluster, axis=0)

            # Calculate the loss
            loss = np.mean([np.mean([self.manhattan_distance(x, median) for x in cluster]) for median, cluster in zip(self.medians, clusters)])
            losses.append(loss)
            iteration += 1

            print(f'Iteration {iteration}: Loss = {loss}')

            if loss <= self.loss_threshold and iteration >= 3:
                break

        return losses, self.medians, iteration

# Load the Iris dataset
iris = load_iris()
X = iris.data

# Set k=3
k = 3

# Q3 PART 2 SECTION A
# Initialize and fit the KMedian model
kmedian = KMedian(n_clusters=k)
losses, medians, iterations = kmedian.fit(X)
k_3_centroids_median = medians

# Print the results
print('kmedian')
print(f'K-Median Clustering (k={k})')
print(f'Medians:\n{k_3_centroids_median}')
print(f'Number of Iterations: {iterations}')

# Plotting
plt.figure(figsize=(8, 6))
plt.plot(range(1, len(losses) + 1), losses)
plt.xlabel('Iterations')
plt.ylabel('Loss')
plt.title('Loss vs Iterations(kmedian)')
plt.tight_layout()
plt.show()





# Q3 PART 2 SECTION B
# Load the Iris dataset
iris = load_iris()
x = iris.data
y = iris.target

# Add noisy data points (outliers) to the dataset
np.random.seed(0)
n_outliers = 20
X = np.vstack((x, np.random.rand(n_outliers, x.shape[1]) * 10))

# for k=3
k = 3
print('kmeans++ vs kmedian(outliers)')

# Initialize and fit the KMedian model
kmedian = KMedian(n_clusters=k)
losses, medians, iterations = kmedian.fit(X)

# Print the results
print(f'Medians:\n{medians}')

kmeans = KMeansPlusPlus(n_clusters=k)
losses, centroids, iterations = kmeans.fit(X)
# Print the results
print(f'means:\n{centroids}')

er1 = k_3_centroids-centroids
print("kmeans++ error :",er1)

er2 = k_3_centroids_median-medians
print("kmedian error :",er2)



# additinal part for testing(not wanted in HW)
# k-means++ implement by sklearn librarry
import numpy as np
from sklearn.datasets import load_iris
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

# Load the Iris dataset
iris = load_iris()
X = iris.data

k_values = [3, 4, 5]
silhouette_scores = []

for k in k_values:
    kmeans = KMeans(n_clusters=k, init='k-means++')
    kmeans.fit(X)
    labels = kmeans.labels_
    score = silhouette_score(X, labels)
    silhouette_scores.append(score)

best_k = k_values[np.argmax(silhouette_scores)]

print(f"Silhouette Scores: {silhouette_scores}")
print(f"Best k: {best_k}")
