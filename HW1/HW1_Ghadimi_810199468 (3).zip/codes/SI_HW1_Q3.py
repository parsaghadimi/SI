import pandas as pd
import matplotlib.pyplot as plt
import numpy as np



# reading data from a csv file with pandas
df = pd.read_csv('data.csv')
# get a print of data
print(df.to_string()) 
# plot simple scatter with out colormap
df.plot(kind='scatter',x='sepal_length',y='sepal_width')
plt.show()


# find classes from df
classes = df['class'].values
# declare an empty list
classes_z_o = []
# turn classes into (zero or one) and append into the empty list
for i in range (len(classes)) :
    if classes[i] == "Iris-setosa" :
        classes_z_o.append(0)
    else :
         classes_z_o.append(1)

categories = np.array(classes_z_o)
# declare colors for classes here we choose blue and red
colormap = np.array(['r','b'])
# plot scatter with colormap
df.plot(kind='scatter',x='sepal_length',y='sepal_width',c=colormap[categories])
plt.show()


# find mean of each class and plot it
# Iris-setosa class
by_class = df.groupby('class')
df_2 = by_class.get_group('Iris-setosa')
length_mean = df_2["sepal_length"].mean()
width_mean = df_2["sepal_width"].mean()
# color
color = ['blue','red']
edgecolor = ['darkblue', 'darkred']
# plot
fig, ax  = plt.subplots()
ax.set_title('Iris-setosa class (data mean)')
ax.bar([1, 2], [length_mean, width_mean], width=1,
        tick_label=['sepal_length', 'sepal_width'], align='center',
        color=color, edgecolor=edgecolor, linewidth=3)
plt.show()

# Iris-virginica class
by_class = df.groupby('class')
df_3 = by_class.get_group('Iris-virginica')
length_mean = df_3["sepal_length"].mean()
width_mean = df_3["sepal_width"].mean()
# color
color = ['blue','red']
edgecolor = ['darkblue', 'darkred']
# plot
fig, ax  = plt.subplots()
ax.set_title('Iris-virginica class (data mean)')
ax.bar([1, 2], [length_mean, width_mean], width=1,
        tick_label=['sepal_length', 'sepal_width'], align='center',
        color=color, edgecolor=edgecolor, linewidth=3)
plt.show()


# split test and train data (20/80 %) random
# Shuffle  dataset (random)
shuffle_df = df.sample(frac=1)
# train set size
train_size = int(0.8 * len(df))
# Split  dataset into test and train sets
train_set = shuffle_df[:train_size]
test_set = shuffle_df[train_size:]




class SVM:
    def __init__(self, C=1):
        # C = error term
        self.C = C
        self.w = np.zeros((1, 2))
        self.b = 0

    # Hinge Loss Function / Calculation
    def hingeloss(self, w, b, x, y):
        # Regularizer term
        reg = 0.5 * np.dot(w, w.T)
        loss = 0
        for i in range(x.shape[0]):
            # Optimization term
            opt_term = y[i] * (np.dot(w, x[i]) + b)
            # calculating loss
            loss += reg + self.C * max(0, 1 - opt_term)
        return loss[0][0]

    def fit(self, X, Y, batch_size=100, learning_rate=0.001, epochs=1000):
        # The number of features in X
        number_of_features = X.shape[1]
        # The number of Samples in X
        number_of_samples = X.shape[0]
        c = self.C
        # Creating ids from 0 to number_of_samples - 1
        ids = np.arange(number_of_samples)
        # Shuffling the samples randomly
        np.random.shuffle(ids)
        # creating an array of zeros
        w = np.zeros((1, number_of_features))
        b = 0
        losses = []
        for i in range(len(Y)):
                if Y[i] == "Iris-setosa" :
                        Y[i] = 0                    
                else :
                        Y[i] = 1
        # Gradient Descent logic
        for i in range(epochs):
            # Calculating the Hinge Loss
            l = self.hingeloss(w, b, X, Y)
            # Appending all losses
            losses.append(l)
            # Starting from 0 to the number of samples with batch_size as interval
            for batch_initial in range(0, number_of_samples, batch_size):
                gradw = 0
                gradb = 0
                for j in range(batch_initial, batch_initial + batch_size):
                    if j < number_of_samples:
                        x = ids[j]
                        ti = Y[x] * (np.dot(w, X[x].T) + b)
                        if ti > 1:
                            gradw += 0
                            gradb += 0
                        else:
                            # Calculating the gradients
                            # w.r.t w
                            gradw += c * Y[x] * X[x]
                            # w.r.t b
                            gradb += c * Y[x]
                # Updating weights and bias
                w = w - learning_rate * w + learning_rate * gradw
                b = b + learning_rate * gradb
        self.w = w
        self.b = b
        return self.w, self.b, losses

    def predict(self, X):
        prediction = np.dot(X, self.w[0]) + self.b  # w.x + b
        for i in range(len(prediction)) :
                if prediction[i] < 1 :
                        prediction[i] = 0
                else :
                        prediction[i] = 1
        return prediction



svm = SVM()
x_train = np.asarray(train_set.iloc[:, 1:3].copy())
label_train = np.asarray(train_set.iloc[:, 3].copy())
x_test = np.asarray(test_set.iloc[:, 1:3].copy())
label_test = np.asarray(test_set.iloc[:, 3].copy())

w, b, losses = svm.fit(x_train, label_train)

prediction = svm.predict(x_test)

# Loss value
lss = losses.pop()
print("Loss:", lss)
print("Prediction:", prediction)
print("w, b:", [w, b])


# Visualizing SVM
classes = df['class'].values
classes_z_o = []

for i in range (len(classes)) :
    if classes[i] == "Iris-setosa" :
        classes_z_o.append(0)
    else :
         classes_z_o.append(1)

categories = np.array(classes_z_o)
colormap = np.array(['r','b'])

df.plot(kind='scatter',x='sepal_length',y='sepal_width',c=colormap[categories])
# plot margin and boundry lines

plt.show()