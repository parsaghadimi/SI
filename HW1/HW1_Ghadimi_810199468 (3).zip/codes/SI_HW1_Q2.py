import matplotlib.pyplot as plt
import numpy as np
import random

PI = 3.14

# declare f(x,y)
def f(x, y):
    return 2*(x)**2 + 2*(y)**2 - 12*y* ( np.sin(0.2*PI*x) ) - x*y

x = np.linspace(-5, 5, 50)
y = np.linspace(0, 10, 50)
X, Y = np.meshgrid(x, y)
Z = f(X,Y)

# 3d plot of f(x,y)
fig = plt.figure()
ax = plt.axes(projection='3d')
ax.plot_surface(X, Y, Z, rstride=1, cstride=1,cmap='jet', edgecolor = 'none')
plt.show()

# minimum of f(x,y)
min_op = np.min(Z)
print("minimum value of Z is : ",min_op) 

# first and second derivative of f(x,y)
def first_derivative_x(x, y):
    dz_dx = 4*x - 2.4*PI*y*(np.cos(0.2*PI*x)) - y
    return dz_dx

def first_derivative_y(x, y):
    dz_dy = 4*y - 12*(np.sin(0.2*PI*x)) - x
    return dz_dy

def second_derivative_x(x, y):
    dz2_dx2 = 4 + 0.48*PI*PI*y*(np.sin(0.2*PI*x))
    return dz2_dx2

def second_derivative_y(x, y):
    dz2_dy2 = 4
    return dz2_dy2

def second_derivative_xy(x, y):
    dz2_dydx = -1 -2.4*PI*(np.cos(0.2*PI*x))
    return dz2_dydx

x_0 = np.array([1,3])
stepsize = 0.5

# declaration of gradian and hesian of f(x,y)
Hf = np.array([[second_derivative_x(x_0[0], x_0[1]),second_derivative_xy(x_0[0], x_0[1])],
            [second_derivative_xy(x_0[0], x_0[1]),second_derivative_y(x_0[0], x_0[1])]])
print('hesian of function is : ',Hf)

Gf = np.array([first_derivative_x(x_0[0], x_0[1]),first_derivative_y(x_0[0], x_0[1])])
print('gradian of function is : ',Gf)

# direction formula in newton method
D = - np.dot(np.linalg.inv(Hf), Gf)
print('newton method direction is : ',D)

C_1 = 10 ** -3 
# best decrease constant
alpha = 0.8 

# check and iterate untill get to a good point
for i in range(50) :
    x_1 = x_0 + stepsize*D
    f_x_0 = f(x_0[0],x_0[1])
    f_x_1 = f(x_1[0],x_1[1])
    if f_x_1 <= f_x_0 + C_1*stepsize* (np.dot(Gf.transpose(),D)) :
        print("x_1 is : ",x_1)
        print("iteration : ",i)
        f_x_1 = f(x_1[0],x_1[1])
        print("the result is (newton) : ",f_x_1)
        print("Difference of min_op and result (error) : ",f_x_1 - min_op)
        print("DONE !!!!!")
        break
    else :
        stepsize = stepsize*alpha
 



# simulated annealing
def simulated_annealing():
    # Initial state use the min we find from newton method
    current_solution = [-2.39,-3.1]
    best_solution = current_solution.copy()

    # Parameters
    temperature = 1000
    cooling_rate = 0.01
    iterations = 1000

    for i in range(iterations):
        # Generate a new solution 
        new_solution = [current_solution[0] + random.uniform(-1, 1),
                        current_solution[1] + random.uniform(-1, 1)]

        current_f = f(current_solution[0], current_solution[1])
        new_f = f(new_solution[0], new_solution[1])

        # checking
        if new_f < current_f:
            current_solution = new_solution.copy()
            if new_f < f(best_solution[0], best_solution[1]):
                best_solution = new_solution.copy()
        else:
            acceptance_probability = np.exp((current_f - new_f) / temperature)
            if random.random() < acceptance_probability:
                current_solution = new_solution.copy()

        # Cooling temperature
        temperature = (1 - cooling_rate) * temperature

    return best_solution

simulated_annealing_point = simulated_annealing()
f_simulated_ann = f(simulated_annealing_point[0],simulated_annealing_point[1])
print("simulated anneling_point is : ",simulated_annealing_point)
print("the result is (simulated annealing) : ",f_simulated_ann)
print("Difference of min_op and result (error) : ",f_simulated_ann - min_op)