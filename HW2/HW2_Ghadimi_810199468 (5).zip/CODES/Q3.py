# Q3 PART A,B,C(C2,C3),D
import matplotlib.pyplot as plt
from sklearn.datasets import load_wine
import numpy as np
from metric_learn import LMNN,LFDA
import pandas as pd
import seaborn as sns

# load data
data = load_wine()
# knn class
class KNN:
    def __init__(self, k):
        self.k = k

    def fit(self, X, y):
        self.X_train = X
        self.y_train = y

    def euclidean_distance(self, x1, x2):
        return np.sqrt(np.sum((x1 - x2) ** 2))

    def predict(self, X):
        y_pred = []
        near_labels = []
        for x_test in X:
            distances = []
            for x_train, y_train in zip(self.X_train, self.y_train):
                dist = self.euclidean_distance(x_test, x_train)
                distances.append((dist, y_train))

            distances.sort(key=lambda x: x[0])
            k_nearest = distances[:self.k]
            k_nearest_labels = [label for _, label in k_nearest]
            near_labels.append(k_nearest_labels)
            most_common = max(set(k_nearest_labels), key=k_nearest_labels.count)
            y_pred.append(most_common)
        return y_pred , near_labels

# calculate accuracy
def calculate_accuracy(y_true, y_pred):
    correct_predictions = 0
    total_samples = len(y_true)

    for true_label, pred_label in zip(y_true, y_pred):
        if true_label == pred_label:
            correct_predictions += 1

    accuracy = correct_predictions / total_samples
    return accuracy

# calculate confusion matrix
def calculate_confusion_matrix(y_true, y_pred):
    num_classes = len(np.unique(y_true))
    confusion_matrix = np.zeros((num_classes, num_classes), dtype=int)

    for true_label, pred_label in zip(y_true, y_pred):
        confusion_matrix[true_label][pred_label] += 1

    return confusion_matrix

# normalize data
def normalize_data(X):
    X_normalized = (X - np.mean(X, axis=0)) / np.std(X, axis=0)
    return X_normalized


# Q3 PART A
# run knn model for diffrent k's
k = [1,5,10,20]
for i in range(4):
    # Shuffle the data randomly
    indices = np.random.permutation(len(data.data))
    X = data.data[indices]
    Y = data.target[indices]
    # Normalize the data
    X_normalized = normalize_data(X)

    # Calculate the index for splitting the data
    split_index = int(0.8 * len(X_normalized))
    # Split the data into training and test sets
    x_train = X_normalized[:split_index]
    x_test = X_normalized[split_index:]
    y_train = Y[:split_index]
    y_test = Y[split_index:]

    # knn model
    knn = KNN(k[i])
    # knn fit function
    knn.fit(x_train, y_train)
    # knn prediction
    prediction = knn.predict(x_test)
    # creat confusion matrix
    confusion_matrix = calculate_confusion_matrix(y_test, prediction[0])
    # estimate accuracy
    accuracy = calculate_accuracy(y_test, prediction[0])
    # results
    print("for k : ",k[i])
    print("near labels are : ", prediction[1])
    print("Prediction is : ", prediction[0])
    print("Accuracy is : ", accuracy)
    print("Confusion Matrix is : ","\n",confusion_matrix)

    label_true_predict = []
    label_false_predict = []
    countp = 0
    countn = 0

    # find true labels and false labels in nn
    if k[i] != 1 :
        for s in range(len(prediction[0])) :
            countp = 0
            countn = 0
            if prediction[0][s] == y_test[s] :
                for j in range(k[i]) :
                    if prediction[1][s][j] == y_test[s] :
                        countp = countp + 1
                label_true_predict.append(countp/k[i])
            else :
                for j in range(k[i]) :
                    if prediction[1][s][j] != y_test[s] :
                        countn = countn + 1
                label_false_predict.append(countn/k[i])

    # Q3 PART B
    # plot true and false nearest_neighbor probability
    if k[i] != 1 :
        colors = ['blue', 'red', 'green', 'orange', 'purple', 'brown', 'pink', 'gray', 'olive']

        # Create subplots for true and false answer probabilities
        fig, axes = plt.subplots(1, 2, figsize=(12, 6))

        # Plot for true answer probabilities
        unique_labels, label_counts = np.unique(label_true_predict, return_counts=True)
        axes[0].bar(unique_labels, label_counts, width=0.1, align='center', color=colors)
        axes[0].set_xlabel('cond')
        axes[0].set_ylabel('count')
        axes[0].set_title(f'The probability of choosing a true answer for k = {k[i]}')

        # Plot for false answer probabilities
        colors.append('black')
        unique_labels, label_counts = np.unique(label_false_predict, return_counts=True)
        axes[1].bar(unique_labels, label_counts, width=0.1, align='center', color=colors)
        axes[1].set_xlabel('cond')
        axes[1].set_ylabel('count')
        axes[1].set_title(f'The probability of choosing a false answer for k = {k[i]}')

        plt.tight_layout()
        plt.show()



# Q3 PART C2
# (if u want to use dimetion reductio use n_components=2 otherwise remove it)
k_values = [1, 5, 15]
# Apply LMNN and LFDA with different k values for dimensionality reduction
for k in k_values:
    # Shuffle the data randomly
    indices = np.random.permutation(len(data.data))
    X = data.data[indices]
    Y = data.target[indices]
    # Normalize the data
    X_normalized = normalize_data(X)
    
    # Instantiate the LMNN object
    transformer = LMNN(n_components=2,k=k)
    # Apply LMNN to transform the data
    transformed_data = transformer.fit_transform(X_normalized, Y)

    # Plot the transformed data
    plt.figure()
    plt.scatter(transformed_data[:, 0], transformed_data[:, 1], c=Y, cmap='viridis')
    plt.xlabel('Feature 1')
    plt.ylabel('Feature 2')
    plt.title(f'LMNN Transformed Data (k={k})')
    plt.colorbar()
    plt.show()

    # Instantiate the LFDA object
    transformer_1 = LFDA(n_components=2,k=k)
    # Apply LFDA to transform the data
    transformed_data_1 = transformer_1.fit_transform(X_normalized, Y)
    # Plot the transformed data
    plt.figure()
    plt.scatter(transformed_data[:, 0], transformed_data_1[:, 1], c=Y, cmap='viridis')
    plt.xlabel('Feature 1')
    plt.ylabel('Feature 2')
    plt.title(f'LFDA Transformed Data (k={k})')
    plt.colorbar()
    plt.show()


# Q3 PART C3
k_values = [15]
for k in k_values:    
    k1 =[1,5,10,20]
    for k2 in k1 :
        # Shuffle the data randomly
        indices = np.random.permutation(len(data.data))
        X = data.data[indices]
        Y = data.target[indices]
        # Normalize the data
        X_normalized = normalize_data(X)

        # Instantiate the LMNN object
        transformer = LMNN(n_components=2,k=k)
        # Apply LMNN to transform the data
        transformed_data_lmnn = transformer.fit_transform(X_normalized, Y)

        # Instantiate the LFDA object
        transformer_1 = LFDA(n_components=2,k=k)
        # Apply LFDA to transform the data
        transformed_data_lfda = transformer_1.fit_transform(X_normalized, Y)

        # Split the transformed data into training and test sets
        split_index = int(0.8 * len(transformed_data_lmnn))
        x_train_lmnn = transformed_data_lmnn[:split_index]
        x_test_lmnn = transformed_data_lmnn[split_index:]
        y_train = Y[:split_index]
        y_test = Y[split_index:]
        # Instantiate the kNN classifier
        knn_lmnn = KNN(k2)
        # Fit the kNN classifier on the LMNN transformed data
        knn_lmnn.fit(x_train_lmnn, y_train)
        # Predict labels using kNN on the LMNN transformed data
        y_pred_lmnn, _ = knn_lmnn.predict(x_test_lmnn)
        # Calculate accuracy
        accuracy_lmnn = calculate_accuracy(y_test, y_pred_lmnn)
        # Calculate confusion matrix
        confusion_matrix_lmnn = calculate_confusion_matrix(y_test, y_pred_lmnn)

        # Split the transformed data into training and test sets
        split_index = int(0.8 * len(transformed_data_lfda))
        x_train_lfda = transformed_data_lfda[:split_index]
        x_test_lfda = transformed_data_lfda[split_index:]

        # Instantiate the kNN classifier
        knn_lfda = KNN(k2)
        # Fit the kNN classifier on the LFDA transformed data
        knn_lfda.fit(x_train_lfda, y_train)
        # Predict labels using k-NN on the LFDA transformed data
        y_pred_lfda, _ = knn_lfda.predict(x_test_lfda)
        # Calculate accuracy
        accuracy_lfda = calculate_accuracy(y_test, y_pred_lfda)
        # Calculate confusion matrix
        confusion_matrix_lfda = calculate_confusion_matrix(y_test, y_pred_lfda)

        # Print results
        print("k for knn is : ",k2)
        print(f'LMNN Transformed Data (k={k})')
        print('Accuracy:', accuracy_lmnn)
        print('Confusion Matrix:\n', confusion_matrix_lmnn)

        print("k for knn is : ",k2)
        print(f'\nLFDA Transformed Data (k={k})')
        print('Accuracy:', accuracy_lfda)
        print('Confusion Matrix:\n', confusion_matrix_lfda)

        # Plot the transformed data for both LMNN and LFDA
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))

        axes[0].scatter(x_train_lmnn[:, 0], x_train_lmnn[:, 1], c=y_train, cmap='viridis', label='Training Data')
        axes[0].scatter(x_test_lmnn[:, 0], x_test_lmnn[:, 1], c='red', marker='x', label='Test Data')
        axes[0].set_xlabel('Feature 1')
        axes[0].set_ylabel('Feature 2')
        axes[0].set_title(f'LMNN Transformed Data (k={k}) & kNN (k={k2})')
        axes[0].legend()

        axes[1].scatter(x_train_lfda[:, 0], x_train_lfda[:, 1], c=y_train, cmap='viridis', label='Training Data')
        axes[1].scatter(x_test_lfda[:, 0], x_test_lfda[:, 1], c='red', marker='x', label='Test Data')
        axes[1].set_xlabel('Feature 1')
        axes[1].set_ylabel('Feature 2')
        axes[1].set_title(f'LFDA Transformed Data (k={k}) & kNN (k={k2})')
        axes[1].legend()

        plt.tight_layout()
        plt.show()



# Q3 PART D
# data-frame of wine data
df = pd.DataFrame(data.data, columns=data.feature_names)

# Normalize data
X_normalized = normalize_data(df.values)

# Dimensionality reduction using LMNN
lmnn = LMNN(n_components=2,k=15)
X_lmnn = lmnn.fit_transform(X_normalized, data.target)

# Dimensionality reduction using LFDA
lfda = LFDA(n_components=2,k=15)
X_lfda = lfda.fit_transform(X_normalized, data.target)

# Calculate correlation matrices with .corr from pandas
correlation_lmnn = pd.DataFrame(X_lmnn).corr()
correlation_lfda = pd.DataFrame(X_lfda).corr()
correlation_matrix = df.corr()

# Plot correlation matrix for data(wine-data)
plt.figure(figsize=(10, 8))
# plot with heatmap from seaborn
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm')
plt.title('Correlation Matrix - DATA')
plt.show()

# Create subplots for LMNN and LFDA correlation matrices
fig, axes = plt.subplots(1, 2, figsize=(12, 6))
# Plot correlation matrix for LMNN
sns.heatmap(correlation_lmnn, annot=True, cmap='coolwarm', ax=axes[0])
axes[0].set_title('Correlation Matrix - LMNN')
# Plot correlation matrix for LFDA
sns.heatmap(correlation_lfda, annot=True, cmap='coolwarm', ax=axes[1])
axes[1].set_title('Correlation Matrix - LFDA')

plt.tight_layout()
plt.show()



