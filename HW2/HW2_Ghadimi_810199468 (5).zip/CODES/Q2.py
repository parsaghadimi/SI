# Q2 PART A,B,C
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix

# Q2 PART A
# node class
class Node:
    def __init__(self):
        self.feature_index = None
        self.threshold = None
        self.left = None
        self.right = None
        self.label = None

# decision tree class
class DecisionTree:
    def __init__(self, max_depth=None):
        self.max_depth = max_depth
    # fit function
    def fit(self, X, y):
        self.n_classes = len(np.unique(y))
        self.n_features = X.shape[1]
        self.tree = self.build_tree(X, y)
    
    def build_tree(self, X, y, depth=0):
        # Create a node
        node = Node()
        
        # Check for termination conditions (depth condition)
        if depth == self.max_depth or len(np.unique(y)) == 1:
            node.label = np.argmax(np.bincount(y))
            return node
        
        # Find the best split
        best_gain = -1
        best_feature_index = None
        best_threshold = None
        
        for feature_index in range(self.n_features):
            # print("X shape:", X.shape)
            # print("feature_index:", feature_index)
            # print("Unique feature indices:", np.unique(feature_index))
            thresholds = np.unique(X[:, feature_index])
            
            for threshold in thresholds:
                gain = self.information_gain(X, y, feature_index, threshold)
                
                if gain > best_gain:
                    best_gain = gain
                    best_feature_index = feature_index
                    best_threshold = threshold
        
        if best_feature_index is None or best_gain == 0:
            node.label = np.argmax(np.bincount(y))
            return node
        
        node.feature_index = best_feature_index
        node.threshold = best_threshold
        
        # Split the data
        left_mask = X[:, best_feature_index] <= best_threshold
        right_mask = ~left_mask
        
        left_X, left_y = X[left_mask], y[left_mask]
        right_X, right_y = X[right_mask], y[right_mask]
        
        # Recursively build the left and right sub_trees
        node.left = self.build_tree(left_X, left_y, depth + 1)
        node.right = self.build_tree(right_X, right_y, depth + 1)
        
        return node
    
    # qalqulate information gain
    def information_gain(self, X, y, feature_index, threshold):
        parent_entropy = self.entropy(y)
        
        left_mask = X[:, feature_index] <= threshold
        right_mask = ~left_mask
        
        n_left = np.sum(left_mask)
        n_right = np.sum(right_mask)
        
        if n_left == 0 or n_right == 0:
            return 0
        
        left_entropy = self.entropy(y[left_mask])
        right_entropy = self.entropy(y[right_mask])
        
        child_entropy = (n_left / len(y)) * left_entropy + (n_right / len(y)) * right_entropy
        gain = parent_entropy - child_entropy
        
        return gain
    
    # calculate entropy
    def entropy(self, y):
        _, counts = np.unique(y, return_counts=True)
        probabilities = counts / len(y)
        entropy = -np.sum(probabilities * np.log2(probabilities))
        return entropy
    
    # prediction
    def predict(self, X):
        return np.array([self.recursive_tree(x, self.tree) for x in X])
    
    def recursive_tree(self, x, node):
        if node.label is not None:
            return node.label
        
        if x[node.feature_index] <= node.threshold:
            return self.recursive_tree(x, node.left)
        else:
            return self.recursive_tree(x, node.right)

# calculate confusion matrix
def calculate_confusion_matrix(y_true, y_pred):
    num_classes = len(np.unique(y_true))
    confusion_matrix = np.zeros((num_classes, num_classes), dtype=int)

    for true_label, pred_label in zip(y_true, y_pred):
        confusion_matrix[true_label][pred_label] += 1

    return confusion_matrix

# reading data from a csv file with pandas
df = pd.read_csv('prison_dataset.csv')

column_classes = df.nunique()
# print(column_classes)

# Define the categorical columns to encode
categorical_columns = ['Fiscal Year Released', 'Recidivism Reporting Year', 'Race - Ethnicity', 'Age At Release',
                       'Convicting Offense Classification', 'Convicting Offense Type', 'Convicting Offense Subtype',
                       'Main Supervising District', 'Release Type', 'Part of Target Population']

# Perform one-hot encoding for each categorical column
encoded_df = pd.get_dummies(df, columns=categorical_columns)
# Print the encoded DataFrame
# print(encoded_df)

# Separate the features (X) and the target variable (y)
X = encoded_df.drop('Recidivism - Return to Prison numeric', axis=1)  
# print("x is :",X)

y = encoded_df['Recidivism - Return to Prison numeric']
# print("y is :",y)

# Separate the features (X) and the target variable (y)
X = encoded_df.drop('Recidivism - Return to Prison numeric', axis=1).values
y = encoded_df['Recidivism - Return to Prison numeric'].values

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# print("x shape",X.shape)
# print("xtrian shape",X_train.shape)
# num_features = X_train.shape[1]
# valid_feature_indices = range(num_features)
# print("Valid feature indices:", valid_feature_indices)

# Create an instance of the DecisionTree class with a maximum depth
print("+ + + + + + +")
print("decision tree")
print("+ + + + + + +")
depth_input = [3,4,5,6,10,15]
for i in depth_input :
    print("max_depth is :",i)
    tree = DecisionTree(max_depth=i)

    # Train the decision tree
    tree.fit(X_train, y_train)

    # Make predictions on the test set
    y_pred = tree.predict(X_test)

    # Calculate the accuracy of the model
    accuracy = (y_pred == y_test).mean()
    print("Accuracy:", accuracy)



    # Calculate the confusion matrix
    cm = calculate_confusion_matrix(y_test, y_pred)
    print("Confusion Matrix:")
    print(cm)
    print("---------")



# Q2 PART B
# Random Forest class
class RandomForest:
    def __init__(self, num_trees, max_depth=None):
        self.num_trees = num_trees
        self.max_depth = max_depth
        self.trees = []
    
    def fit(self, X, y):
        for _ in range(self.num_trees):
            tree = DecisionTree(max_depth=self.max_depth)
            indices = np.random.choice(len(X), size=len(X), replace=True)
            tree.fit(X[indices], y[indices])
            self.trees.append(tree)
    
    def predict(self, X):
        predictions = np.zeros((len(X), self.num_trees))
        for i, tree in enumerate(self.trees):
            predictions[:, i] = tree.predict(X)
        
        majority_votes = np.apply_along_axis(lambda x: np.argmax(np.bincount(x.astype(np.int64))), axis=1, arr=predictions)
        return majority_votes

depth_input = [3,4,5,6,10,15]
number_of_trees = [3,4,5]
print("+ + + + + + +")
print("random forest")
print("+ + + + + + +")
for i in depth_input :
    print("max_depth is :",i)
    for j in number_of_trees :
        # Create an instance of the RandomForest class with 3 trees and a maximum depth of 5
        random_forest = RandomForest(num_trees=j, max_depth=i)

        # Train the random forest
        random_forest.fit(X_train, y_train)

        # Make predictions on the test set
        y_pred = random_forest.predict(X_test)

        print("num_trees is :",j)
        # Calculate the accuracy of the model
        accuracy = (y_pred == y_test).mean()
        print("Accuracy RF:", accuracy)

        # Calculate the confusion matrix
        cm = calculate_confusion_matrix(y_test, y_pred)
        print("Confusion Matrix RF:")
        print(cm)
        print("---------")



# Q2 PART C
print("+ + + + + + +")
print("random forest with sklearn")
print("+ + + + + + +")
# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

# Create an instance of the RandomForestClassifier
random_forest = RandomForestClassifier(max_depth=3, random_state=0)

# Train the random forest
random_forest.fit(X_train, y_train)

# Make predictions on the test set
y_pred = random_forest.predict(X_test)

# Calculate the accuracy of the model
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

# Calculate the confusion matrix
cm = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:")
print(cm)