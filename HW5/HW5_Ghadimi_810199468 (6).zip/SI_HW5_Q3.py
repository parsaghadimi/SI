import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix, precision_score, recall_score
from sklearn.model_selection import train_test_split

# Q3 USING SKLEARN
print("PART 2 USING SKLEARN")
# Load the iris dataset from the CSV file
filename = 'IRIS.csv'
df = pd.read_csv(filename)

# Encode the categorical labels
label_encoder = LabelEncoder()
df['species_encoded'] = label_encoder.fit_transform(df['species'])

# Extract the features (X) and labels (y) from the dataframe
X = df.iloc[:, :-2]  
y = df['species_encoded']

# Normalize the numerical features
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Create a Gaussian Naive Bayes classifier
nb_classifier = GaussianNB()

# Train the classifier
nb_classifier.fit(X_train, y_train)

# Make predictions on the test set
y_pred = nb_classifier.predict(X_test)

# Evaluate the classifier
accuracy = (y_pred == y_test).mean()
print("Accuracy:", accuracy)

# Calculate confusion matrix
confusion_mat = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:")
print(confusion_mat)

# Calculate precision
precision = precision_score(y_test, y_pred, average='macro')
print("Precision:", precision)

# Calculate recall
recall = recall_score(y_test, y_pred, average='macro')
print("Recall:", recall)

print("...................")
print("PART 2 DONE (SKLEARN) !!!")
print("...................")

# Q3 FROM SCRATCH
class NaiveBayesClassifier:
    def __init__(self, alpha=1):
        self.alpha = alpha
        self.class_probabilities = {}
        self.feature_probabilities = {}

    def fit(self, X_train, y_train):
        # Calculate class probabilities
        class_counts = y_train.value_counts()
        total_samples = len(y_train)
        for class_label, count in class_counts.items():
            self.class_probabilities[class_label] = (count + self.alpha) / (total_samples + self.alpha * len(class_counts))

        # Calculate feature probabilities with Laplace smoothing
        for feature in X_train.columns:
            self.feature_probabilities[feature] = {}
            for class_label in self.class_probabilities:
                feature_values = X_train.loc[y_train == class_label, feature]
                self.feature_probabilities[feature][class_label] = {
                    'mean': (feature_values.sum() + self.alpha) / (len(feature_values) + self.alpha * X_train[feature].nunique()),
                    'std': feature_values.std()
                }

    def _calculate_log_likelihood(self, feature_value, mean, std):
        if std == 0:
            return 0  # Skip if standard deviation is zero
        log_likelihood = -0.5 * np.log(2 * np.pi * std**2) - 0.5 * ((feature_value - mean) / std)**2
        return log_likelihood

    def _predict_sample(self, sample):
        class_scores = {}
        for class_label in self.class_probabilities:
            class_score = np.log(self.class_probabilities[class_label])
            for feature, values in sample.items():
                mean = self.feature_probabilities[feature][class_label]['mean']
                std = self.feature_probabilities[feature][class_label]['std']
                log_likelihood = self._calculate_log_likelihood(values, mean, std)
                class_score += log_likelihood
            class_scores[class_label] = class_score
        predicted_class = max(class_scores, key=class_scores.get)
        return predicted_class

    def predict(self, X_test):
        predictions = []
        for _, row in X_test.iterrows():
            predicted_class = self._predict_sample(row)
            predictions.append(predicted_class)
        return predictions

# Load the iris dataset from the CSV file
filename = 'IRIS.csv'  
df = pd.read_csv(filename)

# Encode the categorical labels
label_encoder = LabelEncoder()
df['species_encoded'] = label_encoder.fit_transform(df['species'])

# Extract the features (X) and labels (y) from the dataframe
X = df.iloc[:, :-2]
y = df['species_encoded']

# Normalize the numerical features
scaler = StandardScaler()
numeric_columns = X.select_dtypes(include=[np.number]).columns
X[numeric_columns] = scaler.fit_transform(X[numeric_columns])

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Create and train the Naive Bayes classifier
nb_classifier = NaiveBayesClassifier(alpha=1)
nb_classifier.fit(X_train, y_train)

# Make predictions on the test set
y_pred = nb_classifier.predict(X_test)

# Evaluate the classifier
accuracy = (y_pred == y_test).mean()
print("Accuracy:", accuracy)

# Calculate confusion matrix
confusion_mat = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:")
print(confusion_mat)

# Calculate precision
precision = precision_score(y_test, y_pred, average='macro', zero_division=0)
print("Precision:", precision)

# Calculate recall
recall = recall_score(y_test, y_pred, average='macro')
print("Recall:", recall)

print("...................")
print("PART 1 DONE (SCRATCH) !!!")
print("...................")